#!/usr/bin/env bash
#
# This script will localize the file manager
# so that all of the paths are localized to
# the current location of the template repo.

sed "s|PWD|$(pwd)|g" settings/template_file_manager.1hr.txt > settings/file_manager.txt

var=(airpres
     airtemp
     LWRadAtm
     pptrate
     spechum
     SWRadAtm
     windspd)

x=1

for (( x=0; x<${#var[@]}; x++ )); do
   suff=${var[$x]} 
   sed "s|PWD|$(pwd)|g; s|/1hr|/constant|g; s|forcingFileList.1hr|forcingFileList.constant_$suff|g; s|camels_1hr_|camels_constant_$suff|g" settings/template_file_manager.1hr.txt > settings/file_manager_constant_$suff.txt;
done
sed "s|PWD|$(pwd)|g; s|/1hr|/truth|g; s|forcingFileList.1hr|forcingFileList.truth|g; s|camels_1hr_|camels_truth|g" settings/template_file_manager.1hr.txt > settings/file_manager_truth.txt;
